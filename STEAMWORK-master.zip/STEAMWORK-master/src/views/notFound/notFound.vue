<template>
  <div>Whoops!</div>
</template>

<script>
    export default {
        name: "notFound"
    }
</script>

<style scoped>

</style>