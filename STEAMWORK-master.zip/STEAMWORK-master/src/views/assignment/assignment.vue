<template>
  <el-container>
    <el-header><Nav></Nav></el-header>
    <el-main class="main-box">
      <h3 style="margin-top:5px;">3D打印&nbsp;课时1：&nbsp;#课时1的标题#</h3>
      <el-row :gutter="0">
        <!-- 这里是教学步骤栏，放置一列按钮组展示相应课程的教学步骤 -->
        <el-col :span="7" ><Steps></Steps></el-col>
        <!-- 这里是教学步骤内容展示栏，放置教学视频、图片 -->
        <el-col :span="16" class="vshow"><Videoshow></Videoshow></el-col>
      </el-row>
    </el-main>
    <el-footer><Footer></Footer></el-footer>
  </el-container>
</template>

<script>
    import Nav from "../../components/hd-nav";
    import Footer from "../../components/hd-footer";
    import Steps from "../../components/assignment/steps";
    import Videoshow from "../../components/assignment/video-show";

    export default {
        name: "Assignment",
        components: {Videoshow ,Steps, Footer, Nav},
        props: [
            'id'
        ],
        data () {
            return {
                name: '3d打印'
            }
        }
    }
</script>

<style scoped>
  *{
    margin-left: 0px;
    padding-left: 0px;
  }
  .main-box{
    margin-left: 10px;
  }
  .template{
    overflow-x: hidden;
  }
  .vshow{
    float: right;
  }
</style>
