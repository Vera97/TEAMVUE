<template>
    <div id="periods">
        <!--        <p>3D打印 课时1 #写下你的标题#</p>-->
        <div><el-button type="primary" plain class="periods-length">步骤1</el-button></div>
        <div><el-button type="primary" plain class="periods-length">步骤2</el-button></div>
        <div><el-button type="primary" plain class="periods-length">步骤3</el-button></div>
        <div><el-button type="primary" plain class="periods-length">步骤4</el-button></div>
        <div><el-button type="primary" plain class="periods-length">步骤5</el-button></div>
        <div><el-button type="primary" plain class="periods-length">步骤6</el-button></div>
        <div><el-button type="primary" plain class="periods-length">……</el-button></div>
        <div><el-button type="primary" class="periods-length">资源下载</el-button></div>
    </div>

</template>

<script>


</script>

<style scoped>
    .periods-length {
        width: 90%;
        text-align: center;
        margin: 0.9%;
    }
</style>
