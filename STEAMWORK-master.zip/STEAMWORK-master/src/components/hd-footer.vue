<template>
    <div class="copyright">
       &copy; Copyright 2019 <b>hedouclass.com</b> &nbsp; | &nbsp; All rights reserved.
        <a href="#" target="_blank" title="禾斗创课">禾斗创课</a>
    </div>
</template>

<script>
    export default {
        name: "hd-footer"
    }
</script>

<style scoped lang="scss">
  .copyright {
    color: #ffffff;
    background-color: #409EFF;
    padding: 20px;
    bottom: 0;
    width: 100%;
    font-size: 14px;
    margin-left: 0;
    border: none;

    a {
      color: #fff;
    }
  }
</style>

