//test
export const getCount = state => {
    return state.course
};
