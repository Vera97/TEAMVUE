//
export const push_course_async = (commit, course) => {
    commit('PUSH_COURSE', course)
};
