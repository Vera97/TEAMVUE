module.exports = {
    assetsDir: 'static'
}
