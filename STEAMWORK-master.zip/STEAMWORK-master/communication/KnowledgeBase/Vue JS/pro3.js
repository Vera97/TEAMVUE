let p = Promise.resolve(2)

console.log(p)

p.then(console.log)